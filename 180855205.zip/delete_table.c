#include <stdlib.h>
#include "node.h"

void delete_table(node **htable, unsigned long tabsz) {
	// TODO: walk through the chains in table
	//
	for (unsigned long i = 0; i < tabsz; i++) {
		node *current = htable[i];
		while (current != NULL) {
		  node *next = current->next;

	// TODO: free all the memory associated to each node in each chain
	
		  free(current->id);
 		  free(current);
		  current = next;


	// TODO: free the entire table
		}
	}
	free(htable);
}
